# Pasta de Imagens - FidesFood

Esta pasta contém as imagens utilizadas no projeto FidesFood.

## Como adicionar imagens:

1. **Logo principal**: Substitua o arquivo `logo-fidesfood.svg` pelo logo da sua empresa
2. **Imagem de fundo**: A imagem `mirtilo.jpeg` é usada como background na página de cadastro
3. **Outras imagens**: Adicione quantas imagens precisar seguindo a convenção de nomenclatura

## Arquivos atuais:
- `mirtilo.jpeg` - Imagem de fundo usada na página de cadastro (lado esquerdo)
- `cereja.png` - Imagem anterior (não utilizada)
- `mirtilo_cereja.png` - Imagem anterior (não utilizada)
- `logo-fidesfood.svg` - Logo vetorial usado como fallback

## Formatos recomendados:
- PNG para logos e imagens com transparência
- JPG/JPEG para fotos e imagens de fundo
- SVG para ícones e gráficos vetoriais

## Tamanhos recomendados:
- Logo: 128x128px ou 256x256px
- Ícones: 32x32px, 64x64px ou 128x128px
- Imagens de fundo: Otimizadas para web (recomendamos ferramentas como TinyPNG)

## Nota:
Se alguma imagem não for encontrada, ela será automaticamente ocultada e apenas o texto será exibido.
