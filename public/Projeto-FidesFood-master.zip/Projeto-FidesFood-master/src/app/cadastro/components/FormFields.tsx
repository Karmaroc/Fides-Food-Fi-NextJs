import { FormData } from '../hooks/useCadastroForm';

interface FormFieldProps {
  formData: FormData;
  tipoUsuario: 'comercio' | 'consumidor';
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
}

export const FormFields = ({ formData, tipoUsuario, handleInputChange }: FormFieldProps) => {
  return (
    <>
      {/* CPF/CNPJ */}
      <div>
        <label htmlFor="cpf" className="block text-sm font-medium text-gray-700 mb-2">
          {tipoUsuario === 'comercio' ? 'CNPJ *' : 'CPF *'}
        </label>
        <input
          type="text"
          id="cpf"
          name="cpf"
          value={formData.cpf}
          onChange={handleInputChange}
          placeholder={tipoUsuario === 'comercio' ? '00.000.000/0000-00' : '000.000.000-00'}
          className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
            tipoUsuario === 'consumidor'
              ? 'focus:ring-blue-500'
              : 'focus:ring-orange-500'
          }`}
          required
        />
      </div>

      {/* Nome Completo */}
      <div>
        <label htmlFor="nomeCompleto" className="block text-sm font-medium text-gray-700 mb-2">
          Nome Completo *
        </label>
        <input
          type="text"
          id="nomeCompleto"
          name="nomeCompleto"
          value={formData.nomeCompleto}
          onChange={handleInputChange}
          placeholder="Digite seu nome completo"
          className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
            tipoUsuario === 'consumidor'
              ? 'focus:ring-blue-500'
              : 'focus:ring-orange-500'
          }`}
          required
        />
      </div>

      {/* Data de Nascimento */}
      <div>
        <label htmlFor="dataNascimento" className="block text-sm font-medium text-gray-700 mb-2">
          Data de Nascimento *
        </label>
        <input
          type="date"
          id="dataNascimento"
          name="dataNascimento"
          value={formData.dataNascimento}
          onChange={handleInputChange}
          className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
            tipoUsuario === 'consumidor'
              ? 'focus:ring-blue-500'
              : 'focus:ring-orange-500'
          }`}
          required
        />
      </div>

      {/* Email */}
      <div>
        <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
          Email *
        </label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
          placeholder="seu@email.com"
          className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
            tipoUsuario === 'consumidor'
              ? 'focus:ring-blue-500'
              : 'focus:ring-orange-500'
          }`}
          required
        />
      </div>

    </>
  );
};
