'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ContinuacaoCadastro() {
  const router = useRouter();
  const [tipoUsuario, setTipoUsuario] = useState<'comercio' | 'consumidor'>('consumidor');
  const [formData, setFormData] = useState({
    cpf: '',
    nomeCompleto: '',
    cep: '',
    endereco: '',
    complemento: '',
    numero: '',
    bairro: '',
    cidade: '',
    estado: '',
    telefone: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const buscarCEP = async (cep: string) => {
    if (cep.length === 8) {
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
        const data = await response.json();
        if (data && !data.erro) {
          setFormData(prev => ({
            ...prev,
            endereco: data.logradouro || '',
            bairro: data.bairro || '',
            cidade: data.localidade || '',
            estado: data.uf || ''
          }));
        }
      } catch (error) {
        console.error('Erro ao buscar CEP:', error);
      }
    }
  };

  const handleCEPSearch = () => {
    if (formData.cep.length === 8) {
      buscarCEP(formData.cep);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simular processamento do formulário
    console.log('Dados completos do formulário:', { tipoUsuario, ...formData });

    // Redirecionar para a página de sucesso após o cadastro completo
    router.push('/sucesso');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-blue-900 to-orange-900 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="relative p-8 flex flex-col justify-center items-center text-white min-h-[500px] bg-cover bg-center bg-no-repeat"
                 style={{
                   backgroundImage: 'url("/images/mirtilo.jpeg")'
                 }}>
              <div className="relative z-10 text-center mt-16">
                <h2 className="text-xl font-bold mb-2 text-white" style={{ fontFamily: 'Play, sans-serif' }}>Sejam bem-aventurados ao cadastro do</h2>
                <h1 className="text-3xl mb-3 text-white">
                  <span className="bg-gradient-to-r from-orange-400 to-orange-600 bg-clip-text text-transparent" style={{ fontFamily: 'SUSE, monospace' }}>Fides</span>
                  <span className="bg-gradient-to-r from-orange-500 to-orange-700 bg-clip-text text-transparent" style={{ fontFamily: 'Keania One, cursive' }}>Food</span>
                </h1>
                <p className="text-sm text-white" style={{ fontFamily: 'Play, sans-serif' }}>Complete seu cadastro!</p>
              </div>
            </div>

            {/* Lado direito - Formulário */}
            <div className="p-6">
              <h2 className="text-2xl font-bold text-center text-blue-900 mb-6">
                Continue seu cadastro
              </h2>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* CEP */}
                <div>
                  <label htmlFor="cep" className="block text-sm font-medium text-gray-700 mb-2">
                    CEP *
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      id="cep"
                      name="cep"
                      value={formData.cep}
                      onChange={handleInputChange}
                      placeholder="00000-000"
                      className={`flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                        tipoUsuario === 'consumidor'
                          ? 'focus:ring-blue-500'
                          : 'focus:ring-orange-500'
                      }`}
                      required
                    />
                    <button
                      type="button"
                      onClick={handleCEPSearch}
                      className={`px-4 py-2 rounded-md font-medium text-sm transition-colors ${
                        tipoUsuario === 'consumidor'
                          ? 'bg-blue-600 hover:bg-blue-700 text-white'
                          : 'bg-orange-600 hover:bg-orange-700 text-white'
                      }`}
                    >
                      Buscar
                    </button>
                  </div>
                </div>

                {/* Endereço e Número */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="endereco" className="block text-sm font-medium text-gray-700 mb-2">
                      Endereço *
                    </label>
                    <input
                      type="text"
                      id="endereco"
                      name="endereco"
                      value={formData.endereco}
                      onChange={handleInputChange}
                      placeholder="Nome da rua, avenida, etc."
                      className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                        tipoUsuario === 'consumidor'
                          ? 'focus:ring-blue-500'
                          : 'focus:ring-orange-500'
                      }`}
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="numero" className="block text-sm font-medium text-gray-700 mb-2">
                      Número *
                    </label>
                    <input
                      type="text"
                      id="numero"
                      name="numero"
                      value={formData.numero}
                      onChange={handleInputChange}
                      placeholder="Número da casa/apartamento"
                      className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                        tipoUsuario === 'consumidor'
                          ? 'focus:ring-blue-500'
                          : 'focus:ring-orange-500'
                      }`}
                      required
                    />
                  </div>
                </div>

                {/* Bairro e Complemento */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="bairro" className="block text-sm font-medium text-gray-700 mb-2">
                      Bairro *
                    </label>
                    <input
                      type="text"
                      id="bairro"
                      name="bairro"
                      value={formData.bairro}
                      onChange={handleInputChange}
                      className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                        tipoUsuario === 'consumidor'
                          ? 'focus:ring-blue-500'
                          : 'focus:ring-orange-500'
                      }`}
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="complemento" className="block text-sm font-medium text-gray-700 mb-2">
                      Complemento
                    </label>
                    <input
                      type="text"
                      id="complemento"
                      name="complemento"
                      value={formData.complemento}
                      onChange={handleInputChange}
                      placeholder="Apartamento, bloco, etc. (opcional)"
                      className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                        tipoUsuario === 'consumidor'
                          ? 'focus:ring-blue-500'
                          : 'focus:ring-orange-500'
                      }`}
                    />
                  </div>
                </div>

                {/* Cidade e Estado */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="cidade" className="block text-sm font-medium text-gray-700 mb-2">
                      Cidade *
                    </label>
                    <input
                      type="text"
                      id="cidade"
                      name="cidade"
                      value={formData.cidade}
                      onChange={handleInputChange}
                      className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                        tipoUsuario === 'consumidor'
                          ? 'focus:ring-blue-500'
                          : 'focus:ring-orange-500'
                      }`}
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="estado" className="block text-sm font-medium text-gray-700 mb-2">
                      Estado *
                    </label>
                    <select
                      id="estado"
                      name="estado"
                      value={formData.estado}
                      onChange={handleInputChange}
                      className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                        tipoUsuario === 'consumidor'
                          ? 'focus:ring-blue-500'
                          : 'focus:ring-orange-500'
                      }`}
                      required
                    >
                      <option value="">Selecione</option>
                      <option value="AC">Acre</option>
                      <option value="AL">Alagoas</option>
                      <option value="AP">Amapá</option>
                      <option value="AM">Amazonas</option>
                      <option value="BA">Bahia</option>
                      <option value="CE">Ceará</option>
                      <option value="DF">Distrito Federal</option>
                      <option value="ES">Espírito Santo</option>
                      <option value="GO">Goiás</option>
                      <option value="MA">Maranhão</option>
                      <option value="MT">Mato Grosso</option>
                      <option value="MS">Mato Grosso do Sul</option>
                      <option value="MG">Minas Gerais</option>
                      <option value="PA">Pará</option>
                      <option value="PB">Paraíba</option>
                      <option value="PR">Paraná</option>
                      <option value="PE">Pernambuco</option>
                      <option value="PI">Piauí</option>
                      <option value="RJ">Rio de Janeiro</option>
                      <option value="RN">Rio Grande do Norte</option>
                      <option value="RS">Rio Grande do Sul</option>
                      <option value="RO">Rondônia</option>
                      <option value="RR">Roraima</option>
                      <option value="SC">Santa Catarina</option>
                      <option value="SP">São Paulo</option>
                      <option value="SE">Sergipe</option>
                      <option value="TO">Tocantins</option>
                    </select>
                  </div>
                </div>

                {/* Telefone */}
                <div>
                  <label htmlFor="telefone" className="block text-sm font-medium text-gray-700 mb-2">
                    Telefone *
                  </label>
                  <input
                    type="tel"
                    id="telefone"
                    name="telefone"
                    value={formData.telefone}
                    onChange={handleInputChange}
                    placeholder="(00) 00000-0000"
                    className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                      tipoUsuario === 'consumidor'
                        ? 'focus:ring-blue-500'
                        : 'focus:ring-orange-500'
                    }`}
                    required
                  />
                </div>

                {/* Botão Finalizar Cadastro */}
                <div className="pt-4">
                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-blue-600 to-orange-600 text-white py-3 px-4 rounded-md font-medium hover:from-blue-700 hover:to-orange-700 transition-all focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                  >
                    Finalizar Cadastro
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
