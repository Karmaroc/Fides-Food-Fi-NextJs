'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCadastroForm } from './hooks/useCadastroForm';

export default function Cadastro() {
  const router = useRouter();
  const [tipoUsuario, setTipoUsuario] = useState<'comercio' | 'consumidor'>('consumidor');
  const { formData, handleInputChange } = useCadastroForm(tipoUsuario);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Dados do formulário:', { tipoUsuario, ...formData });
    // Navegar para a página de continuação do cadastro
    router.push('/cadastro/continuacao');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-blue-900 to-orange-900 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="relative p-8 flex flex-col justify-center items-center text-white min-h-[500px] bg-cover bg-center bg-no-repeat"
                 style={{
                   backgroundImage: 'url("/images/mirtilo.jpeg")'
                 }}>
              <div className="relative z-10 text-center mt-16">
                <h2 className="text-xl font-bold mb-2 text-white" style={{ fontFamily: 'Play, sans-serif' }}>Sejam bem-aventurados ao cadastro do</h2>
                <h1 className="text-3xl mb-3 text-white">
                  <span className="bg-gradient-to-r from-orange-400 to-orange-600 bg-clip-text text-transparent" style={{ fontFamily: 'SUSE, monospace' }}>Fides</span>
                  <span className="bg-gradient-to-r from-orange-500 to-orange-700 bg-clip-text text-transparent" style={{ fontFamily: 'Keania One, cursive' }}>Food</span>
                </h1>
                <p className="text-sm text-white" style={{ fontFamily: 'Play, sans-serif' }}>Façam uma boa compra!</p>
              </div>
            </div>

            {/* Lado direito - Formulário */}
            <div className="p-6">
              <h2 className="text-2xl font-bold text-center text-blue-900 mb-6">
                Comece seu cadastro
              </h2>

              {/* Seleção de tipo de usuário */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Tipo de Conta
                </label>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setTipoUsuario('consumidor')}
                    className={`flex-1 py-3 px-4 rounded-lg border-2 font-medium transition-colors text-sm ${
                      tipoUsuario === 'consumidor'
                        ? 'border-blue-600 bg-blue-50 text-blue-700'
                        : 'border-gray-300 text-gray-600 hover:border-gray-400'
                    }`}
                  >
                    Consumidor
                  </button>
                  <button
                    type="button"
                    onClick={() => setTipoUsuario('comercio')}
                    className={`flex-1 py-3 px-4 rounded-lg border-2 font-medium transition-colors text-sm ${
                      tipoUsuario === 'comercio'
                        ? 'border-orange-600 bg-orange-50 text-orange-700'
                        : 'border-gray-300 text-gray-600 hover:border-gray-400'
                    }`}
                  >
                    Comércio
                  </button>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* CPF/CNPJ */}
                <div>
                  <label htmlFor="cpf" className="block text-sm font-medium text-gray-700 mb-2">
                    {tipoUsuario === 'comercio' ? 'CNPJ *' : 'CPF *'}
                  </label>
                  <input
                    type="text"
                    id="cpf"
                    name="cpf"
                    value={formData.cpf}
                    onChange={handleInputChange}
                    placeholder={tipoUsuario === 'comercio' ? '00.000.000/0000-00' : '000.000.000-00'}
                    className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                      tipoUsuario === 'consumidor'
                        ? 'focus:ring-blue-500'
                        : 'focus:ring-orange-500'
                    }`}
                    required
                  />
                </div>

                {/* Nome Completo */}
                <div>
                  <label htmlFor="nomeCompleto" className="block text-sm font-medium text-gray-700 mb-2">
                    Nome Completo *
                  </label>
                  <input
                    type="text"
                    id="nomeCompleto"
                    name="nomeCompleto"
                    value={formData.nomeCompleto}
                    onChange={handleInputChange}
                    placeholder="Digite seu nome completo"
                    className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                      tipoUsuario === 'consumidor'
                        ? 'focus:ring-blue-500'
                        : 'focus:ring-orange-500'
                    }`}
                    required
                  />
                </div>

                {/* Data de Nascimento */}
                <div>
                  <label htmlFor="dataNascimento" className="block text-sm font-medium text-gray-700 mb-2">
                    Data de Nascimento *
                  </label>
                  <input
                    type="date"
                    id="dataNascimento"
                    name="dataNascimento"
                    value={formData.dataNascimento}
                    onChange={handleInputChange}
                    className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                      tipoUsuario === 'consumidor'
                        ? 'focus:ring-blue-500'
                        : 'focus:ring-orange-500'
                    }`}
                    required
                  />
                </div>

                {/* Email */}
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Email *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="seu@email.com"
                    className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:border-transparent ${
                      tipoUsuario === 'consumidor'
                        ? 'focus:ring-blue-500'
                        : 'focus:ring-orange-500'
                    }`}
                    required
                  />
                </div>

                {/* Botão Confirmar */}
                <div className="pt-4">
                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-blue-600 to-orange-600 text-white py-3 px-4 rounded-md font-medium hover:from-blue-700 hover:to-orange-700 transition-all focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                  >
                    Continuar
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
