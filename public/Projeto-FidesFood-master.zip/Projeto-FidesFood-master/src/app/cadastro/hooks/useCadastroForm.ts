import { useState } from 'react';

export interface FormData {
  cpf: string;
  nomeCompleto: string;
  dataNascimento: string;
  endereco: string;
  complemento: string;
  numero: string;
  bairro: string;
  cidade: string;
  estado: string;
  email: string;
  telefone: string;
}

export interface UserType {
  tipoUsuario: 'comercio' | 'consumidor';
}

export const useCadastroForm = (tipoUsuario: 'comercio' | 'consumidor') => {
  const [formData, setFormData] = useState<FormData>({
    cpf: '',
    nomeCompleto: '',
    dataNascimento: '',
    endereco: '',
    complemento: '',
    numero: '',
    bairro: '',
    cidade: '',
    estado: '',
    email: '',
    telefone: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return {
    formData,
    setFormData,
    handleInputChange
  };
};
